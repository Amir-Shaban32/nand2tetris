# Defines constants for VM command types used by the Parser and CodeWriter.

C_ARITHMETIC = "C_ARITHMETIC"
C_PUSH = "push"
C_POP = "pop"